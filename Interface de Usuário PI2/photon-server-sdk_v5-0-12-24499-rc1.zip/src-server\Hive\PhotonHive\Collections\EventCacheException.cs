﻿using System;

namespace Photon.Hive.Collections
{
    public class EventCacheException : Exception
    {
        public EventCacheException(string msg) : base(msg)
        { }
    }
}