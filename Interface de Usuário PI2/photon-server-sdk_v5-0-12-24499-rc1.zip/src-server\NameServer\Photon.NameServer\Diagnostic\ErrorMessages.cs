﻿namespace Photon.NameServer.Diagnostic
{
    public static class ErrorMessages
    {
        public const string SecureConnectionRequired = "According to account setting user should use one of secure connection type - WSS";
    }
}
