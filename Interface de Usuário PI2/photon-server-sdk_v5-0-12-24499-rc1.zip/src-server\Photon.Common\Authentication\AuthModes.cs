﻿namespace Photon.Common.Authentication
{
    public enum AuthModes
    {
        TraditionalMode,
        EncryptionSupportMode,
    }
}
