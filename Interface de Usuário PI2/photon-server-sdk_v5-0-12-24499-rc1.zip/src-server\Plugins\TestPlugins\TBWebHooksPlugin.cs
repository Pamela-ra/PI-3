﻿using Photon.Hive.Plugin.WebHooks;

namespace TestPlugins
{
    public class TBWebHooksPlugin : WebHooksPlugin
    {
        public override string Name
        {
            get { return "TBWebhooks"; }
        }
    }
}